from colorama import Fore, Style, init

def say_hello():
    # Initialize colorama
    init(autoreset=True)
    
    # Выводим текст красным цветом
    print(Fore.RED + "Hello, world!")

